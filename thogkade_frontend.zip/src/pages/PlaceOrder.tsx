
function PlaceOrder() {
  return <div>PlaceOrder</div>
}

export default PlaceOrder