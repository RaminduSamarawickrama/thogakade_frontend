
export default function Dashboard() {
  return (
    <div className="p-6">
      <h1>Thogakade</h1>
    </div>
  )
}
